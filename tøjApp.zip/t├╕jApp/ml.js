// More API functions here:
// https://github.com/googlecreativelab/teachablemachine-community/tree/master/libraries/image

// the link to your model provided by Teachable Machine export panel
const URL = "https://teachablemachine.withgoogle.com/models/5Fdi6M2wc/";

let model, webcam, labelContainer, maxPredictions;

// Load the image model and setup the webcam
async function init() {
    const modelURL = URL + "model.json";
    const metadataURL = URL + "metadata.json";

    // load the model and metadata
    // Refer to tmImage.loadFromFiles() in the API to support files from a file picker
    // or files from your local hard drive
    // Note: the pose library adds "tmImage" object to your window (window.tmImage)
    model = await tmImage.load(modelURL, metadataURL);
    maxPredictions = model.getTotalClasses();

    // Convenience function to setup a webcam
    const flip = true; // whether to flip the webcam
    webcam = new tmImage.Webcam(200, 200, flip); // width, height, flip
    await webcam.setup(); // request access to the webcam
    await webcam.play();
    window.requestAnimationFrame(loop);

    // append elements to the DOM
    document.getElementById("webcam-container").appendChild(webcam.canvas);
    labelContainer = document.getElementById("label-container");
    for (let i = 0; i < maxPredictions; i++) { // and class labels
        labelContainer.appendChild(document.createElement("div"));
    }
}

async function loop() {
    webcam.update(); // update the webcam frame
    window.requestAnimationFrame(loop);
}


// run the webcam image through the image model
async function predict() {

    labelContainer = document.getElementById("label-container");
    const prediction = await model.predict(webcam.canvas);
    for (let i = 0; i < maxPredictions; i++) {
        const classPrediction = prediction[i].className + ": " + prediction[i].probability.toFixed(2);

        //labelContainer.childNodes[i].innerHTML = classPrediction;


        
        if (prediction[i].probability > 0.85) {

            // Skriv resultatet til konsollen i browseren
            console.log(prediction[i].className, prediction[i].probability);

            if (prediction[i].className == "saks") {
                document.getElementById("obj_saks").style.backgroundColor = "orange";
                document.getElementById("label-container").innerHTML = "<a href='https://www.lomax.dk/flere-produkter/hobbyartikler/sakse-tape-og-lim/specialsakse-og-knive/'>Sakse hos Lomax</a>";
                document.getElementById("obj_kop").style.backgroundColor = "white";
                document.getElementById("obj_mobil").style.backgroundColor = "white";
            }
            if (prediction[i].className == "mobil") {
                document.getElementById("obj_mobil").style.backgroundColor = "orange";
                document.getElementById("label-container").innerHTML = "<a href='https://www.cbb.dk/shop/mobiltelefoner/?gclid=CjwKCAjwov6hBhBsEiwAvrvN6LqZoLGGHR2V2a8DsFxoV0WLPbhnvsCZ-TXOBgbrh4O5AzIhNZQjRRoC0FYQAvD_BwE'>Mobiltelefoner hos CBB</a>";
                document.getElementById("obj_saks").style.backgroundColor = "white";
                document.getElementById("obj_kop").style.backgroundColor = "white";
            }
        }
    }
}

async function tagBillede() {
    await predict();
}
