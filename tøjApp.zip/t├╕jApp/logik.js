var sakse   = ["Saks 1", "Saks 2", "Saks 3", "saks 4"]
var kopper  = ["", "", "", ""]
var mobiler = ["", "", "", ""]

function visListe (objekt) {
    if (objekt == "saks") {
        return sakse
    }

    // ellers returnér tom liste
    return []
}

// Ryst posen
//let min_liste = visListe("saks").sort(() => Math.random() - 0.5)