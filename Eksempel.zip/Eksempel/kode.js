let m;

function setup() {
  let myCanvas = createCanvas(475, 360);
  myCanvas.parent("root");
  m = new Mover();
}

function draw() {
  background(51);

  let wind = createVector(0.3, 0);
  let gravity = createVector(0, 0.1);
  m.applyForce(wind);
  m.applyForce(gravity);


  m.update();
  m.display();
  m.checkEdges();

}